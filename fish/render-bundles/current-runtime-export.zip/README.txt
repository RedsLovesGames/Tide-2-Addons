Tide Fish Runtime Export
========================

This bundle was generated inside the running Minecraft client.
Fish discovery comes from TideData.FISH. Images are rendered through Tide's actual FishDisplayBlockEntity and FishDisplayRenderer into a transparent framebuffer.
No item-sprite, AI-art, reconstructed-model, or raw-entity fallback is used. Failed renders remain listed in failures.json.
Give this ZIP directly to the Tideborne Fish Wiki importer.
